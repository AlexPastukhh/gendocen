"""Command-line interface for the Generic Documentation Engine."""

from __future__ import annotations

import argparse
import json
import sys
from collections.abc import Sequence

from .output import CommandResult, Issue
from .project import (
    ProjectInitializationError,
    RootDiscoveryError,
    discover_roots,
    initialize_project,
)
from .resources import ResourceCatalog, ResourceError
from .versions import ENGINE_VERSION

COMMANDS = (
    "init",
    "status",
    "check",
    "diff",
    "explain",
    "sync",
    "rebuild",
    "validate",
    "materialize",
    "verify",
    "history",
    "graph",
    "resources",
)


def _add_common_options(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--json", action="store_true", dest="json_output", help="emit versioned JSON envelope")
    parser.add_argument("--project-root", help="explicit project root")
    parser.add_argument("--docs-root", help="explicit documentation root (absolute or project-relative)")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="docengine", description="Generic Documentation Engine")
    parser.add_argument("--version", action="version", version=f"%(prog)s {ENGINE_VERSION}")
    subparsers = parser.add_subparsers(dest="command", required=True)
    for command in COMMANDS:
        sub = subparsers.add_parser(command, help=f"{command} command")
        _add_common_options(sub)
        if command in {"diff", "explain", "rebuild", "validate", "history"}:
            sub.add_argument("target", nargs="?", help="target resource")
        if command == "validate":
            sub.add_argument("--result")
            sub.add_argument("--reason")
    return parser


def _execute_init(args: argparse.Namespace) -> tuple[CommandResult, int]:
    try:
        outcome = initialize_project(project_root=args.project_root, docs_root=args.docs_root)
    except (ProjectInitializationError, RootDiscoveryError) as exc:
        return CommandResult(
            command="init",
            ok=False,
            status="init_failed",
            issues=(Issue(code="init_failed", message=str(exc)),),
        ), 2
    status = "initialized" if outcome.changed else "already_initialized"
    return CommandResult(
        command="init",
        ok=True,
        status=status,
        data={
            "roots": outcome.roots.to_dict(),
            "created": list(outcome.created),
            "existing": list(outcome.existing),
        },
    ), 0


def _execute_resources(args: argparse.Namespace) -> tuple[CommandResult, int]:
    try:
        roots = discover_roots(project_root=args.project_root, docs_root=args.docs_root)
        catalog = ResourceCatalog.scan(roots)
    except (RootDiscoveryError, ResourceError) as exc:
        return CommandResult(
            command="resources",
            ok=False,
            status="resource_scan_failed",
            issues=(Issue(code="resource_scan_failed", message=str(exc)),),
        ), 2
    return CommandResult(command="resources", ok=True, status="ok", data=catalog.to_payload()), 0


def _execute(args: argparse.Namespace) -> tuple[CommandResult, int]:
    if args.command == "init":
        return _execute_init(args)
    if args.command == "resources":
        return _execute_resources(args)

    try:
        roots = discover_roots(project_root=args.project_root, docs_root=args.docs_root)
    except RootDiscoveryError as exc:
        result = CommandResult(
            command=args.command,
            ok=False,
            status="invalid_roots",
            issues=(Issue(code="invalid_roots", message=str(exc)),),
        )
        return result, 2

    result = CommandResult(
        command=args.command,
        ok=False,
        status="not_implemented",
        data={"roots": roots.to_dict()},
        issues=(
            Issue(
                code="phase_not_implemented",
                message=f"'{args.command}' behavior is not implemented yet; current implementation is complete through P1.",
                severity="info",
            ),
        ),
    )
    return result, 2


def _render_human(result: CommandResult) -> str:
    if result.command == "resources" and result.ok:
        data = result.data
        lines = ["docengine resources: ok"]
        roots = data.get("roots", {})
        lines.append(f"documentation_root: {roots.get('documentation_root')}")
        for item in data.get("resources", []):
            suffix = ""
            if "owner_ref" in item:
                suffix = f" owner={item['owner_ref']}"
            lines.append(f"{item['kind'].upper():9} {item['ref']}{suffix}")
        counts = data.get("counts", {})
        lines.append("counts: " + ", ".join(f"{key}={counts[key]}" for key in sorted(counts)))
        return "\n".join(lines)

    if result.command == "init" and result.ok:
        roots = result.data.get("roots", {})
        lines = [f"docengine init: {result.status}"]
        lines.append(f"project_root: {roots.get('project_root')}")
        lines.append(f"documentation_root: {roots.get('documentation_root')}")
        if result.data.get("created"):
            lines.append("created: " + ", ".join(result.data["created"]))
        return "\n".join(lines)

    roots = result.data.get("roots", {})
    lines = [f"docengine {result.command}: {result.status}"]
    if roots:
        lines.extend([
            f"project_root: {roots.get('project_root')}",
            f"documentation_root: {roots.get('documentation_root')}",
        ])
    for issue in result.issues:
        lines.append(f"{issue.severity}: {issue.message}")
    return "\n".join(lines)


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    result, exit_code = _execute(args)
    if args.json_output:
        print(json.dumps(result.to_dict(), ensure_ascii=False, sort_keys=True))
    else:
        print(_render_human(result))
    return exit_code


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())

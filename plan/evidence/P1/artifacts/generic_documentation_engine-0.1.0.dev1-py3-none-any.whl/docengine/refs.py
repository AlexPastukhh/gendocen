"""Stable resource and field references used by the documentation engine."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import PurePosixPath
import re
from urllib.parse import quote, unquote, urlsplit


_NAMESPACE_RE = re.compile(r"^[A-Za-z0-9_-]+$")
_LOCAL_ID_RE = re.compile(r"^[A-Za-z0-9_.-]+$")


class RefError(ValueError):
    """Raised when a resource reference is malformed or ambiguous."""


def _decode_pointer_token(token: str) -> str:
    # RFC 6901 requires only ~0 and ~1 escapes. Reject dangling/unknown escapes.
    out: list[str] = []
    i = 0
    while i < len(token):
        if token[i] != "~":
            out.append(token[i])
            i += 1
            continue
        if i + 1 >= len(token) or token[i + 1] not in "01":
            raise RefError(f"invalid JSON Pointer escape in token: {token!r}")
        out.append("~" if token[i + 1] == "0" else "/")
        i += 2
    return "".join(out)


def _encode_pointer_token(token: str) -> str:
    return token.replace("~", "~0").replace("/", "~1")


def parse_json_pointer(pointer: str | None) -> tuple[str, ...]:
    if pointer in (None, ""):
        return ()
    if not pointer.startswith("/"):
        raise RefError("JSON Pointer must be empty or start with '/'")
    return tuple(_decode_pointer_token(part) for part in pointer[1:].split("/"))


def format_json_pointer(parts: tuple[str, ...]) -> str:
    if not parts:
        return ""
    return "/" + "/".join(_encode_pointer_token(part) for part in parts)


@dataclass(frozen=True, slots=True)
class ResourceRef:
    """Address a managed resource or a whole documentation file.

    Canonical v0.1 forms:
      resource://<namespace>/<id>#/<json-pointer>
      file://<documentation-relative-path>
    """

    scheme: str
    namespace: str | None = None
    resource_id: str | None = None
    file_path: str | None = None
    pointer_parts: tuple[str, ...] = ()

    @classmethod
    def parse(cls, value: str) -> "ResourceRef":
        if not isinstance(value, str) or not value:
            raise RefError("reference must be a non-empty string")
        parsed = urlsplit(value)
        if parsed.query:
            raise RefError("resource references do not support query strings")

        if parsed.scheme == "resource":
            namespace = unquote(parsed.netloc)
            path = parsed.path.lstrip("/")
            if not namespace or not path or "/" in path:
                raise RefError("resource ref must be resource://<namespace>/<id>")
            resource_id = unquote(path)
            if not resource_id or not _NAMESPACE_RE.fullmatch(namespace) or not _LOCAL_ID_RE.fullmatch(resource_id):
                raise RefError("resource namespace/id contain unsupported characters")
            pointer = unquote(parsed.fragment) if parsed.fragment else ""
            return cls(
                scheme="resource",
                namespace=namespace,
                resource_id=resource_id,
                pointer_parts=parse_json_pointer(pointer),
            )

        if parsed.scheme == "file":
            if parsed.fragment:
                raise RefError("file refs are whole-file only in v0.1; fragments are not supported")
            # The specified syntax is file://architecture/rationale.md, so the URI
            # authority is the first path segment rather than a host.
            joined = "/".join(part for part in (parsed.netloc, parsed.path.lstrip("/")) if part)
            if not joined:
                raise RefError("file ref must contain a documentation-relative path")
            decoded = unquote(joined)
            raw_parts = decoded.split("/")
            if any(part in {"", ".", ".."} for part in raw_parts):
                raise RefError("file ref must use non-empty canonical relative path segments")
            path = PurePosixPath(decoded)
            if path.is_absolute():
                raise RefError("file ref must be a confined documentation-relative path")
            return cls(scheme="file", file_path=path.as_posix())

        raise RefError(f"unsupported reference scheme: {parsed.scheme or '<missing>'}")

    @classmethod
    def from_resource_id(cls, resource_id: str, pointer: str | None = None) -> "ResourceRef":
        if "." not in resource_id:
            raise RefError("managed resource_id must contain namespace and id separated by '.'")
        namespace, local_id = resource_id.split(".", 1)
        if not namespace or not local_id:
            raise RefError("managed resource_id must contain non-empty namespace and id")
        if not _NAMESPACE_RE.fullmatch(namespace) or not _LOCAL_ID_RE.fullmatch(local_id):
            raise RefError("managed resource_id contains unsupported characters")
        return cls(
            scheme="resource",
            namespace=namespace,
            resource_id=local_id,
            pointer_parts=parse_json_pointer(pointer),
        )

    @property
    def logical_resource_id(self) -> str | None:
        if self.scheme != "resource":
            return None
        assert self.namespace is not None and self.resource_id is not None
        return f"{self.namespace}.{self.resource_id}"

    @property
    def pointer(self) -> str:
        return format_json_pointer(self.pointer_parts)

    def with_pointer(self, pointer: str) -> "ResourceRef":
        if self.scheme != "resource":
            raise RefError("only structured resource refs may have field pointers")
        return ResourceRef(
            scheme=self.scheme,
            namespace=self.namespace,
            resource_id=self.resource_id,
            pointer_parts=parse_json_pointer(pointer),
        )

    def __str__(self) -> str:
        if self.scheme == "resource":
            assert self.namespace is not None and self.resource_id is not None
            base = f"resource://{quote(self.namespace, safe='-._~')}/{quote(self.resource_id, safe='-._~')}"
            pointer = self.pointer
            return base if not pointer else f"{base}#{quote(pointer, safe='/~') }"
        if self.scheme == "file":
            assert self.file_path is not None
            # Preserve slash separators while URI-escaping path content.
            return "file://" + quote(self.file_path, safe="/-._~")
        raise RefError(f"unsupported reference scheme: {self.scheme}")


FieldRef = ResourceRef

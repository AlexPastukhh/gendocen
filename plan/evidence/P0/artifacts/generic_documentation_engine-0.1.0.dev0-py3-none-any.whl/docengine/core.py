"""Core protocols reserved for later phases.

P0 keeps these abstractions domain-neutral; P1/P2 will provide concrete behavior.
"""

from dataclasses import dataclass
from typing import Any, Protocol


@dataclass(frozen=True)
class ResourceRef:
    scheme: str
    resource_id: str
    pointer: str | None = None


class ResourceStore(Protocol):
    def get(self, ref: ResourceRef) -> Any: ...
    def version(self, ref: ResourceRef) -> str: ...


class BuildContext(Protocol):
    def read(self, ref: ResourceRef) -> Any: ...
    def get(self, ref: ResourceRef) -> Any: ...
    def emit(self, value: Any) -> None: ...


class ValidationContext(Protocol):
    def current(self, ref: ResourceRef) -> Any: ...
    def baseline(self, ref: ResourceRef) -> Any: ...
    def diff(self, ref: ResourceRef) -> Any: ...

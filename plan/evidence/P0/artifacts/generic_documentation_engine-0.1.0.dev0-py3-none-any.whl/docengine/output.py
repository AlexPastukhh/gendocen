"""Stable machine-readable command result envelope."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any

from .versions import ENGINE_VERSION, MACHINE_OUTPUT_SCHEMA_VERSION


@dataclass(frozen=True)
class Issue:
    code: str
    message: str
    severity: str = "error"
    details: dict[str, Any] | None = None


@dataclass(frozen=True)
class CommandResult:
    command: str
    ok: bool
    status: str
    data: dict[str, Any] = field(default_factory=dict)
    issues: tuple[Issue, ...] = ()
    machine_output_schema_version: str = MACHINE_OUTPUT_SCHEMA_VERSION
    engine_version: str = ENGINE_VERSION

    def to_dict(self) -> dict[str, Any]:
        return {
            "machine_output_schema_version": self.machine_output_schema_version,
            "engine_version": self.engine_version,
            "command": self.command,
            "ok": self.ok,
            "status": self.status,
            "data": self.data,
            "issues": [asdict(issue) for issue in self.issues],
        }

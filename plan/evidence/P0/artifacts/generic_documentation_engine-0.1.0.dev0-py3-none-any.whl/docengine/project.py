"""Project/documentation root discovery foundation.

P0 is intentionally read-only. It discovers and validates candidate roots but does
not initialize directories or write configuration; mutation arrives in later phases.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


DEFAULT_CONFIG_NAMES = ("docengine.toml",)


class RootDiscoveryError(ValueError):
    """Raised when project/documentation roots are unsafe or ambiguous."""


@dataclass(frozen=True)
class ProjectRoots:
    project_root: Path
    documentation_root: Path
    source: str

    def to_dict(self) -> dict[str, str]:
        return {
            "project_root": str(self.project_root),
            "documentation_root": str(self.documentation_root),
            "source": self.source,
        }


def _resolved(path: str | Path) -> Path:
    return Path(path).expanduser().resolve(strict=False)


def is_within(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
    except ValueError:
        return False
    return True


def confined_path(root: str | Path, relative_path: str | Path) -> Path:
    root_path = _resolved(root)
    candidate = _resolved(root_path / Path(relative_path))
    if not is_within(candidate, root_path):
        raise RootDiscoveryError(f"path escapes configured root: {relative_path}")
    return candidate


def discover_roots(
    *,
    cwd: str | Path | None = None,
    project_root: str | Path | None = None,
    docs_root: str | Path | None = None,
) -> ProjectRoots:
    """Discover roots without mutating the filesystem.

    P0 supports explicit roots and a deterministic cwd/upward-search skeleton.
    Config parsing is deliberately deferred to P1.
    """

    current = _resolved(cwd or Path.cwd())

    if project_root is not None:
        project = _resolved(project_root)
        source = "explicit"
    else:
        project = current
        source = "cwd"
        try:
            origin_device = current.stat().st_dev
        except OSError:
            origin_device = None
        for candidate in (current, *current.parents):
            try:
                if origin_device is not None and candidate.stat().st_dev != origin_device:
                    break
            except OSError:
                break
            if any((candidate / name).is_file() for name in DEFAULT_CONFIG_NAMES):
                project = candidate
                source = "config_marker"
                break

    documentation = _resolved(docs_root) if docs_root is not None else _resolved(project / "docs")

    if docs_root is not None and project_root is not None and not is_within(documentation, project):
        raise RootDiscoveryError("documentation root must be inside explicit project root")

    return ProjectRoots(project_root=project, documentation_root=documentation, source=source)

"""Version constants kept separate from project/documentation data versions."""

ENGINE_VERSION = "0.1.0.dev0"
PERSISTED_STATE_SCHEMA_VERSION = "1.0.0"
MACHINE_OUTPUT_SCHEMA_VERSION = "1.0.0"

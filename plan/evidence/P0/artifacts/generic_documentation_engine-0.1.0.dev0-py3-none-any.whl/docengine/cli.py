"""P0 CLI foundation.

All future commands are present so their machine-output envelope is stable from the
start. Command behavior beyond foundation/discovery is deliberately not implemented.
"""

from __future__ import annotations

import argparse
import json
import sys
from collections.abc import Sequence

from .output import CommandResult, Issue
from .project import RootDiscoveryError, discover_roots
from .versions import ENGINE_VERSION

COMMANDS = (
    "init",
    "status",
    "check",
    "diff",
    "explain",
    "sync",
    "rebuild",
    "validate",
    "materialize",
    "verify",
    "history",
    "graph",
    "resources",
)


def _add_common_options(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--json", action="store_true", dest="json_output", help="emit versioned JSON envelope")
    parser.add_argument("--project-root", help="explicit project root")
    parser.add_argument("--docs-root", help="explicit documentation root")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="docengine", description="Generic Documentation Engine")
    parser.add_argument("--version", action="version", version=f"%(prog)s {ENGINE_VERSION}")
    subparsers = parser.add_subparsers(dest="command", required=True)
    for command in COMMANDS:
        sub = subparsers.add_parser(command, help=f"{command} command")
        _add_common_options(sub)
        if command in {"diff", "explain", "rebuild", "validate", "history"}:
            sub.add_argument("target", nargs="?", help="target resource")
        if command == "validate":
            sub.add_argument("--result")
            sub.add_argument("--reason")
    return parser


def _execute_foundation(args: argparse.Namespace) -> tuple[CommandResult, int]:
    try:
        roots = discover_roots(project_root=args.project_root, docs_root=args.docs_root)
    except RootDiscoveryError as exc:
        result = CommandResult(
            command=args.command,
            ok=False,
            status="invalid_roots",
            issues=(Issue(code="invalid_roots", message=str(exc)),),
        )
        return result, 2

    # P0 intentionally implements discovery only. No command writes state yet.
    result = CommandResult(
        command=args.command,
        ok=False,
        status="not_implemented",
        data={"roots": roots.to_dict()},
        issues=(
            Issue(
                code="phase_not_implemented",
                message=f"'{args.command}' behavior is not implemented in P0; only CLI/discovery contracts are active.",
                severity="info",
            ),
        ),
    )
    return result, 2


def _render_human(result: CommandResult) -> str:
    roots = result.data.get("roots", {})
    lines = [f"docengine {result.command}: {result.status}"]
    if roots:
        lines.extend([
            f"project_root: {roots.get('project_root')}",
            f"documentation_root: {roots.get('documentation_root')}",
        ])
    for issue in result.issues:
        lines.append(f"{issue.severity}: {issue.message}")
    return "\n".join(lines)


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    result, exit_code = _execute_foundation(args)
    if args.json_output:
        print(json.dumps(result.to_dict(), ensure_ascii=False, sort_keys=True))
    else:
        print(_render_human(result))
    return exit_code


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
